import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editordoughntchart',
  templateUrl: './editordoughntchart.component.html',
  styleUrls: ['./editordoughntchart.component.css']
})
export class EditordoughntchartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
