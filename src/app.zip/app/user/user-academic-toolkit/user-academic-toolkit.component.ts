import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-academic-toolkit',
  templateUrl: './user-academic-toolkit.component.html',
  styleUrls: ['./user-academic-toolkit.component.css']
})
export class UserAcademicToolkitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  frameSrc: string = 'assets/image/Frame 427323442.png';
  frame1Src: string = 'assets/image/Frame 427323442 (1).png';
  frame2Src: string = 'assets/image/Frame 427323442 (2).png';
  BlackSrc: string = 'assets/image/Black.png';
  Black1Src: string = 'assets/image/Black (1).png';
  Black2Src: string = 'assets/image/Black (2).png';
  Black3Src: string = 'assets/image/Black (3).png';
  Black4Src: string = 'assets/image/Black (4).png';
  Black5Src: string = 'assets/image/Black (5).png';
  Black6Src: string = 'assets/image/Black (6).png';
  Black7Src: string = 'assets/image/Black (7).png';
  Black8Src: string = 'assets/image/Black (8).png';
}
